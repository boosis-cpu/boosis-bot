
const BTC_MXN_URL = 'https://api.bitso.com/v3/ticker/?book=btc_mxn';
const USDT_MXN_URL = 'https://api.bitso.com/v3/ticker/?book=usdt_mxn';

async function fetchTicker(url) {
    const response = await fetch(url);
    const data = await response.json();
    return data.success ? data.payload : null;
}

async function monitorMulti() {
    try {
        const [btcData, usdtData] = await Promise.all([
            fetchTicker(BTC_MXN_URL),
            fetchTicker(USDT_MXN_URL)
        ]);

        if (btcData && usdtData) {
            const btcPrice = parseFloat(btcData.last);
            const usdtPrice = parseFloat(usdtData.last);
            const btcInUsd = btcPrice / usdtPrice;
            const time = new Date().toLocaleTimeString();

            console.clear();
            console.log('--- MONITOR MULTI-MONEDA (Bitso) ---');
            console.log(`Hora: ${time}\n`);
            console.log(`1. Bitcoin (BTC/MXN):  $${btcPrice.toLocaleString('es-MX')} MXN`);
            console.log(`2. Dólar (USDT/MXN):   $${usdtPrice.toLocaleString('es-MX')} MXN`);
            console.log('------------------------------------');
            console.log(`PRECIO BTC EN DÓLARES: $${btcInUsd.toLocaleString('en-US', { maximumFractionDigits: 2 })} USDT`);
            console.log('\n[Presiona Ctrl+C para detener]');
        }
    } catch (error) {
        console.error('Error:', error.message);
    }
}

console.log('Iniciando monitor...');
setInterval(monitorMulti, 2000);
monitorMulti();
