
const BINANCE_BTC_KLINES_URL = 'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=576';

// --- CONFIGURACIÓN: ALGORITMO REFINADO (Filtro de Tendencia Mayor) ---
const VENTANA_CORTA = 12;      // 1 hora (para gatillar compra/venta)
const VENTANA_LARGA = 48;      // 4 horas (el FILTRO DE TENDENCIA)
const UMBRAL_SEÑAL = 0.0020;   // 0.20%
const COMISION_BINANCE = 0.0010;

async function runRefinedBacktest() {
    try {
        console.log('--- REFINANDO EL CEREBRO: BITCOIN 48H ---');
        console.log('Aplicando Filtro de Tendencia de 4 horas para evitar ruidos...\n');

        const response = await fetch(BINANCE_BTC_KLINES_URL);
        const klines = await response.json();

        let wallet = { usdt: 1000, btc: 0 };
        let history = [];
        let ops = 0;
        let peak = 1000;
        let mdd = 0;

        klines.forEach((kline, index) => {
            const price = parseFloat(kline[4]);
            history.push(price);
            if (history.length > VENTANA_LARGA) history.shift();

            if (history.length === VENTANA_LARGA) {
                // Cálculo de Promedios
                const smaCorta = history.slice(-VENTANA_CORTA).reduce((a, b) => a + b, 0) / VENTANA_CORTA;
                const smaLarga = history.reduce((a, b) => a + b, 0) / VENTANA_LARGA;

                const diffCorta = (price - smaCorta) / smaCorta;

                // --- EL FILTRO INTELIGENTE ---
                // Solo compramos si el precio actual es mayor al promedio de las últimas 4 horas (TENDENCIA ALCISTA)
                const tendenciaEsAlcista = price > smaLarga;

                // COMPRA con filtro
                if (tendenciaEsAlcista && diffCorta > UMBRAL_SEÑAL && wallet.usdt > 0) {
                    wallet.btc = (wallet.usdt * (1 - COMISION_BINANCE)) / price;
                    wallet.usdt = 0;
                    ops++;
                }
                // VENTA (más agresiva si la tendencia cambia a bajista)
                else if ((diffCorta < -UMBRAL_SEÑAL || price < smaLarga) && wallet.btc > 0) {
                    wallet.usdt = (wallet.btc * price) * (1 - COMISION_BINANCE);
                    wallet.btc = 0;
                    ops++;
                }
            }

            const total = wallet.usdt + (wallet.btc * price);
            if (total > peak) peak = total;
            const dd = ((peak - total) / peak) * 100;
            if (dd > mdd) mdd = dd;
        });

        const finalPrice = parseFloat(klines[klines.length - 1][4]);
        const finalValue = wallet.usdt + (wallet.btc * finalPrice);
        const netProfit = ((finalValue - 1000) / 1000) * 100;

        console.log('--------------------------------------');
        console.log('RESULTADO DEL ALGORITMO REFINADO:');
        console.log(`Saldo Final   : $${finalValue.toFixed(2)} USDT`);
        console.log(`Rendimiento   : \x1b[${netProfit >= -4.6203 ? '32' : '31'}m${netProfit.toFixed(4)}%\x1b[0m (Antiguo: -4.6203%)`);
        console.log(`Operaciones   : ${ops} (Antiguas: 30)`);
        console.log(`Caída Máxima  : ${mdd.toFixed(2)}% (Antigua: 5.79%)`);
        console.log('--------------------------------------');

        if (ops < 30) {
            console.log(`💡 Éxito: El filtro eliminó ${30 - ops} operaciones innecesarias.`);
            console.log('   Menos operaciones = Menos comisiones = Mayor supervivencia.');
        }

    } catch (e) { console.error(e.message); }
}

runRefinedBacktest();
