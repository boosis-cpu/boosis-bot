
const DataMiner = require('./src/core/data_miner');
const logger = require('./src/core/logger');

(async () => {
    logger.info('--- TESTING DATA MINER ---');

    const symbol = 'BTCUSDT';
    const interval = '1h';
    const limit = 24; // 1 day of data

    logger.info(`Attempting to harvest ${limit} candles for ${symbol}...`);

    const savedPath = await DataMiner.harvest(symbol, interval, limit);

    if (savedPath) {
        logger.success('Test Passed: Data harvested successfully.');
        logger.info(`File location: ${savedPath}`);
    } else {
        logger.error('Test Failed: No data saved.');
    }
})();
