
const BITSO_XRP_MXN = 'https://api.bitso.com/v3/ticker/?book=xrp_mxn';
const BITSO_USDT_MXN = 'https://api.bitso.com/v3/ticker/?book=usdt_mxn';
const BINANCE_XRP_USDT = 'https://api.binance.com/api/v3/ticker/price?symbol=XRPUSDT';

// --- CONFIGURACIÓN DE "FRICCIÓN" (COMISIONES) ---
const COMISION_BITSO = 0.0050; // 0.50% (Nivel inicial estándar)
const COMISION_BINANCE = 0.0010; // 0.10% (Estándar Binance)
const COMISION_TOTAL = COMISION_BITSO + COMISION_BINANCE;

async function fetchJSON(url) {
    try {
        const response = await fetch(url);
        return await response.json();
    } catch (e) {
        return null;
    }
}

async function comparePrices() {
    console.clear();
    console.log('--- SCANNER DE RENTABILIDAD REAL (Renaissance Mode) ---');
    console.log(`Hora: ${new Date().toLocaleTimeString()}\n`);

    const [bitsoXRP, bitsoUSDT, binanceXRP] = await Promise.all([
        fetchJSON(BITSO_XRP_MXN),
        fetchJSON(BITSO_USDT_MXN),
        fetchJSON(BINANCE_XRP_USDT)
    ]);

    if (bitsoXRP && bitsoUSDT && binanceXRP) {
        const priceBitsoMXN = parseFloat(bitsoXRP.payload.last);
        const priceUSDTMXN = parseFloat(bitsoUSDT.payload.last);
        const priceBinanceUSDT = parseFloat(binanceXRP.price);

        const priceBitsoInUSDT = priceBitsoMXN / priceUSDTMXN;
        const diffPercent = ((priceBitsoInUSDT - priceBinanceUSDT) / priceBinanceUSDT);

        console.log(`🛒 Precio Binance: $${priceBinanceUSDT.toFixed(4)} USDT`);
        console.log(`🇲🇽 Precio Bitso:   $${priceBitsoInUSDT.toFixed(4)} USDT`);
        console.log(`📊 Diferencia Bruta: ${(diffPercent * 100).toFixed(3)}%`);
        console.log(`💸 Gastos (Comisiones): ${(COMISION_TOTAL * 100).toFixed(2)}%`);
        console.log('-------------------------------------------');

        const profitNeto = diffPercent - COMISION_TOTAL;

        if (profitNeto > 0) {
            console.log(`🚀 ¡OPORTUNIDAD DETECTADA!`);
            console.log(`   Ganancia NETA estimada: \x1b[32m+${(profitNeto * 100).toFixed(3)}%\x1b[0m`);
            console.log(`   (Ya restamos las comisiones de ambos exchanges)`);
        } else {
            const falta = (Math.abs(profitNeto) * 100).toFixed(3);
            console.log(`⚪ SIN RENTABILIDAD:`);
            console.log(`   Las comisiones se comen la ganancia. Faltaría un ${falta}% más de diferencia.`);
        }
    } else {
        console.log('Esperando datos de los servidores...');
    }
    console.log('\n[Presiona Ctrl+C para detener]');
}

console.log('Iniciando scanner de rentabilidad...');
setInterval(comparePrices, 3000);
comparePrices();
