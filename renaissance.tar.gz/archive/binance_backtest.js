
const BINANCE_XRP_TRADES_URL = 'https://api.binance.com/api/v3/trades?symbol=XRPUSDT&limit=100';

// --- CONFIGURACIÓN DE LA ESTRATEGIA (Binance Level) ---
const WINDOW_SIZE = 20;
const UMBRAL_SEÑAL = 0.0010;  // 0.10%
const COMISION_BINANCE = 0.0010; // 0.10% (¡6 veces menor que Bitso!)

async function runBinanceBacktest() {
    try {
        console.log('--- BACKTESTING BINANCE (Océano Global) ---');
        console.log('Descargando 100 trades de XRP/USDT desde Binance...\n');

        const response = await fetch(BINANCE_XRP_TRADES_URL);
        const tradesRaw = await response.json();

        if (!Array.isArray(tradesRaw)) {
            console.error('Error al obtener datos:', tradesRaw);
            return;
        }

        // Binance los manda del más antiguo al más reciente por defecto, 
        // pero vamos a asegurarnos de procesarlos en orden temporal.
        const trades = tradesRaw;

        let virtualWallet = { usdt: 1000, xrp: 0 };
        let history = [];
        let operationsCount = 0;

        console.log('Simulando estrategia con comisión de 0.10%...');

        trades.forEach((trade, index) => {
            const price = parseFloat(trade.price);
            history.push(price);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (price - sma) / sma;

                // Lógica de Compra
                if (diff > UMBRAL_SEÑAL && virtualWallet.usdt > 0) {
                    const costoComision = virtualWallet.usdt * COMISION_BINANCE;
                    const netoParaComprar = virtualWallet.usdt - costoComision;
                    virtualWallet.xrp = netoParaComprar / price;
                    virtualWallet.usdt = 0;
                    operationsCount++;
                    console.log(`[Trade ${index}] 🟢 COMPRA a $${price.toFixed(4)} USDT | Comisión: $${costoComision.toFixed(4)}`);
                }
                // Lógica de Venta
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.xrp > 0) {
                    const ventaBruta = virtualWallet.xrp * price;
                    const costoComision = ventaBruta * COMISION_BINANCE;
                    virtualWallet.usdt = ventaBruta - costoComision;
                    virtualWallet.xrp = 0;
                    operationsCount++;
                    console.log(`[Trade ${index}] 🔴 VENTA  a $${price.toFixed(4)} USDT | Comisión: $${costoComision.toFixed(4)}`);
                }
            }
        });

        const finalPrice = parseFloat(trades[trades.length - 1].price);
        const finalValue = virtualWallet.usdt + (virtualWallet.xrp * finalPrice);
        const profitTotal = ((finalValue - 1000) / 1000) * 100;

        console.log('\n--- RESULTADOS EN BINANCE ---');
        console.log(`Saldo Final:           $${finalValue.toFixed(4)} USDT`);
        console.log(`Rendimiento Neto:      ${profitTotal >= 0 ? '+' : ''}${profitTotal.toFixed(4)}%`);
        console.log(`Operaciones:           ${operationsCount}`);
        console.log('-----------------------------');

        if (profitTotal > -1.0 && profitTotal < 1.0) {
            console.log('💡 Observación: En Binance, incluso si no ganas mucho, tus pérdidas por comisión son MÍNIMAS comparado con Bitso.');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

runBinanceBacktest();
