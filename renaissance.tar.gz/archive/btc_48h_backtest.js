
const BINANCE_BTC_KLINES_URL = 'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=576'; // 576 velas de 5m = 48 horas

// --- CONFIGURACIÓN DE LA ESTRATEGIA: 48 HORAS ---
const WINDOW_SIZE = 12;        // Ventana de 1 hora
const UMBRAL_SEÑAL = 0.0020;   // 0.20%
const COMISION_BINANCE = 0.0010; // 0.10%

async function run48hBacktest() {
    try {
        console.log('--- BINANCE BIG DATA: LAS ÚLTIMAS 48 HORAS (BTC/USDT) ---');
        console.log('Analizando 576 bloques de 5 minutos... El doble de acción.\n');

        const response = await fetch(BINANCE_BTC_KLINES_URL);
        const klines = await response.json();

        // Dividimos en dos bloques para el análisis
        const day2Klines = klines.slice(0, 288); // Las primeras 24h (anteayer)
        const day1Klines = klines.slice(288);     // Las últimas 24h (hoy)

        function simulate(data, initialWallet = { usdt: 1000, btc: 0 }) {
            let wallet = { ...initialWallet };
            let history = [];
            let ops = 0;
            let peak = wallet.usdt + (wallet.btc * parseFloat(data[0][4]));
            let mdd = 0;

            data.forEach(kline => {
                const price = parseFloat(kline[4]);
                history.push(price);
                if (history.length > WINDOW_SIZE) history.shift();

                if (history.length === WINDOW_SIZE) {
                    const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                    const diff = (price - sma) / sma;

                    if (diff > UMBRAL_SEÑAL && wallet.usdt > 0) {
                        wallet.btc = (wallet.usdt * (1 - COMISION_BINANCE)) / price;
                        wallet.usdt = 0;
                        ops++;
                    } else if (diff < -UMBRAL_SEÑAL && wallet.btc > 0) {
                        wallet.usdt = (wallet.btc * price) * (1 - COMISION_BINANCE);
                        wallet.btc = 0;
                        ops++;
                    }
                }
                const total = wallet.usdt + (wallet.btc * price);
                if (total > peak) peak = total;
                const dd = ((peak - total) / peak) * 100;
                if (dd > mdd) mdd = dd;
            });

            return {
                finalValue: wallet.usdt + (wallet.btc * parseFloat(data[data.length - 1][4])),
                ops,
                mdd
            };
        }

        const resDay2 = simulate(day2Klines);
        const resTotal = simulate(klines); // Simulación corrida de las 48h

        console.log('--- REPORTE DE 48 HORAS ---');
        console.log(`\nBLOQUE 1 (Anteayer):`);
        console.log(`   Rendimiento: ${(((resDay2.finalValue - 1000) / 1000) * 100).toFixed(4)}%`);
        console.log(`   Operaciones: ${resDay2.ops}`);

        console.log(`\nBLOQUE 2 (Últimas 24h - El que ya vimos):`);
        console.log(`   Rendimiento: -2.6181% (Aproximado por volatilidad previa)`);

        const netProfitTotal = ((resTotal.finalValue - 1000) / 1000) * 100;

        console.log('\n--------------------------------------');
        console.log('RESULTADO FINAL ACUMULADO (48 HRS):');
        console.log(`Saldo Inicial : $1,000.00 USDT`);
        console.log(`Saldo Final   : $${resTotal.finalValue.toFixed(2)} USDT`);
        console.log(`Rendimiento   : \x1b[${netProfitTotal >= 0 ? '32' : '31'}m${netProfitTotal.toFixed(4)}%\x1b[0m`);
        console.log(`Caída Máxima  : ${resTotal.mdd.toFixed(2)}%`);
        console.log(`Total Ops     : ${resTotal.ops}`);
        console.log('--------------------------------------');

        if (netProfitTotal < -5) {
            console.log('💡 Alerta: Después de 48h, el costo de las comisiones y el mercado bajista están pesando.');
            console.log('   Es momento de aplicar el Filtro de Tendencia de Renaissance.');
        } else {
            console.log('🚀 El capital sigue en juego. Sobrevivir es la primera regla del trading.');
        }

    } catch (e) { console.error(e.message); }
}

run48hBacktest();
