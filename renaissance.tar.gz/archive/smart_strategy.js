
const XRP_MXN_URL = 'https://api.bitso.com/v3/ticker/?book=xrp_mxn';

// --- CONFIGURACIÓN DE LA ESTRATEGIA (Renaissance Beginner) ---
const WINDOW_SIZE = 10;      // Cuántos datos usamos para calcular el promedio
const UMBRAL_SEÑAL = 0.0005;  // 0.05% de desviación para considerar una "señal"
let priceHistory = [];
let virtualWallet = { mxn: 1000, xrp: 0 };
let lastAction = 'WAIT';

async function getPrice() {
    try {
        const response = await fetch(XRP_MXN_URL);
        const data = await response.json();
        return parseFloat(data.payload.last);
    } catch (e) { return null; }
}

function calculateSMA(data) {
    if (data.length === 0) return 0;
    return data.reduce((a, b) => a + b, 0) / data.length;
}

async function runStrategy() {
    const currentPrice = await getPrice();
    if (!currentPrice) return;

    priceHistory.push(currentPrice);
    if (priceHistory.length > WINDOW_SIZE) priceHistory.shift();

    const sma = calculateSMA(priceHistory);
    const diff = (currentPrice - sma) / sma;

    console.clear();
    console.log('--- ESTRATEGIA: MOMENTUM INTELIGENTE (XRP) ---');
    console.log(`Hora: ${new Date().toLocaleTimeString()}`);
    console.log(`Billetera Virtual: $${virtualWallet.mxn.toFixed(2)} MXN | ${virtualWallet.xrp.toFixed(2)} XRP`);
    console.log('----------------------------------------------');
    console.log(`Precio Actual: $${currentPrice.toFixed(2)} MXN`);
    console.log(`Promedio (${WINDOW_SIZE} periodos): $${sma.toFixed(2)} MXN`);

    if (priceHistory.length < WINDOW_SIZE) {
        console.log(`\n[ESTADO] Calentando motores... (${priceHistory.length}/${WINDOW_SIZE} datos)`);
        return;
    }

    console.log(`Desviación: ${(diff * 100).toFixed(4)}%`);

    // --- LÓGICA DE DECISIÓN ---
    if (diff > UMBRAL_SEÑAL && lastAction !== 'BUY') {
        // SEÑAL DE COMPRA: El precio está subiendo por encima del promedio
        console.log('\n\x1b[32m🚀 SEÑAL DETECTADA: COMPRA (Tendencia Alcista)\x1b[0m');
        if (virtualWallet.mxn > 0) {
            virtualWallet.xrp = virtualWallet.mxn / currentPrice;
            virtualWallet.mxn = 0;
            lastAction = 'BUY';
        }
    } else if (diff < -UMBRAL_SEÑAL && lastAction !== 'SELL') {
        // SEÑAL DE VENTA: El precio está cayendo por debajo del promedio
        console.log('\n\x1b[31m⚠️ SEÑAL DETECTADA: VENTA (Tendencia Bajista)\x1b[0m');
        if (virtualWallet.xrp > 0) {
            virtualWallet.mxn = virtualWallet.xrp * currentPrice;
            virtualWallet.xrp = 0;
            lastAction = 'SELL';
        }
    } else {
        console.log('\n[ESTADO] Manteniendo posición. Sin cambios claros.');
    }

    // Calcular valor total de la cuenta en MXN
    const totalValue = virtualWallet.mxn + (virtualWallet.xrp * currentPrice);
    const profit = ((totalValue - 1000) / 1000) * 100;

    console.log('----------------------------------------------');
    console.log(`VALOR TOTAL DE CUENTA: $${totalValue.toFixed(2)} MXN`);
    console.log(`RENDIMIENTO: ${profit >= 0 ? '+' : ''}${profit.toFixed(4)}%`);
    console.log('\n[Presiona Ctrl+C para detener]');
}

console.log('Iniciando simulador de estrategia inteligente...');
setInterval(runStrategy, 2000); // Revisar cada 2 segundos
runStrategy();
