
const BINANCE_BTC_KLINES_URL = 'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=5m&limit=288';

// --- CONFIGURACIÓN DE LA ESTRATEGIA: 24 HORAS (Micro-Renaissance) ---
const WINDOW_SIZE = 12;        // Ventana de 1 hora (12 velas de 5 min)
const UMBRAL_SEÑAL = 0.0020;   // 0.20% (Buscamos movimientos con fuerza real)
const COMISION_BINANCE = 0.0010; // 0.10%

async function run24hBacktest() {
    try {
        console.log('--- BINANCE BIG DATA: LAS ÚLTIMAS 24 HORAS (BTC/USDT) ---');
        console.log('Analizando 288 bloques de 5 minutos para ver la película completa...\n');

        const response = await fetch(BINANCE_BTC_KLINES_URL);
        const klines = await response.json();

        let virtualWallet = { usdt: 1000, btc: 0 };
        let history = [];
        let operations = [];
        let peakValue = 1000;
        let maxDrawdown = 0;

        klines.forEach((kline, index) => {
            const closePrice = parseFloat(kline[4]);
            const time = new Date(kline[0]).toLocaleString('es-MX', { hour: '2-digit', minute: '2-digit' });

            history.push(closePrice);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (closePrice - sma) / sma;

                // COMPRA
                if (diff > UMBRAL_SEÑAL && virtualWallet.usdt > 0) {
                    const fee = virtualWallet.usdt * COMISION_BINANCE;
                    virtualWallet.btc = (virtualWallet.usdt - fee) / closePrice;
                    virtualWallet.usdt = 0;
                    operations.push({ type: 'BUY', time: time, price: closePrice });
                }
                // VENTA
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.btc > 0) {
                    const gross = virtualWallet.btc * closePrice;
                    const fee = gross * COMISION_BINANCE;
                    virtualWallet.usdt = gross - fee;
                    virtualWallet.btc = 0;
                    operations.push({ type: 'SELL', time: time, price: closePrice });
                }
            }

            // Calcular valor actual para estadísticas de riesgo
            const currentTotal = virtualWallet.usdt + (virtualWallet.btc * closePrice);
            if (currentTotal > peakValue) peakValue = currentTotal;
            const drawDown = ((peakValue - currentTotal) / peakValue) * 100;
            if (drawDown > maxDrawdown) maxDrawdown = drawDown;
        });

        console.log('--- BITÁCORA DE OPERACIONES (Resumen) ---');
        if (operations.length === 0) {
            console.log('No se detectaron oportunidades que superaran el umbral de riesgo.');
        } else {
            operations.forEach(op => {
                console.log(`[${op.time}] ${op.type === 'BUY' ? '🟢 COMPRA' : '🔴 VENTA '} at $${op.price.toFixed(2)}`);
            });
        }

        const finalPrice = parseFloat(klines[klines.length - 1][4]);
        const startPrice = parseFloat(klines[0][4]);
        const finalValue = virtualWallet.usdt + (virtualWallet.btc * finalPrice);
        const netProfit = ((finalValue - 1000) / 1000) * 100;
        const marketReturn = ((finalPrice - startPrice) / startPrice) * 100;

        console.log('\n--- RESULTADOS FINALES DE 24 HORAS ---');
        console.log(`Rendimiento del Mercado: ${marketReturn >= 0 ? '+' : ''}${marketReturn.toFixed(2)}%`);
        console.log(`Rendimiento del BOT:     ${netProfit >= 0 ? '+' : ''}${netProfit.toFixed(4)}%`);
        console.log(`Operaciones Totales:     ${operations.length}`);
        console.log(`Caída Máxima (Risk):     ${maxDrawdown.toFixed(2)}%`);
        console.log(`Saldo Final:             $${finalValue.toFixed(2)} USDT`);
        console.log('--------------------------------------');

        if (netProfit > marketReturn) {
            console.log('🏆 ¡EL BOT VENCIÓ AL MERCADO! Logró proteger el capital o ganar más que solo comprando.');
        } else if (netProfit > 0) {
            console.log('👍 El bot fue rentable, pero el mercado subió más rápido.');
        } else {
            console.log('💡 El bot perdió menos que el mercado o está ajustando su estrategia.');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

run24hBacktest();
