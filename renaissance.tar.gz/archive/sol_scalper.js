
const BINANCE_SOL_TRADES_URL = 'https://api.binance.com/api/v3/trades?symbol=SOLUSDT&limit=1000';

// --- CONFIGURACIÓN DEL SCALPER PARA SOLANA (Extrema Sensibilidad) ---
const WINDOW_SIZE = 20;
const UMBRAL_SEÑAL = 0.0001;   // 0.01% (Extremadamente fino)
const COMISION_BINANCE = 0.0010; // 0.10%

async function runSolanaScalper() {
    try {
        console.log('--- BINANCE SCALPER: OBJETIVO SOLANA (SOL/USDT) ---');
        console.log('Analizando los últimos 1000 movimientos del "Ferrari" de las criptos...\n');

        const response = await fetch(BINANCE_SOL_TRADES_URL);
        const trades = await response.json();

        let virtualWallet = { usdt: 1000, sol: 0 };
        let history = [];
        let buyCount = 0;
        let sellCount = 0;

        trades.forEach((trade, index) => {
            const price = parseFloat(trade.price);
            history.push(price);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (price - sma) / sma;

                // COMPRA
                if (diff > UMBRAL_SEÑAL && virtualWallet.usdt > 0) {
                    const fee = virtualWallet.usdt * COMISION_BINANCE;
                    virtualWallet.sol = (virtualWallet.usdt - fee) / price;
                    virtualWallet.usdt = 0;
                    buyCount++;
                    console.log(`[Trade ${index}] 🟢 BUY SOL  at $${price.toFixed(2)}`);
                }
                // VENTA
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.sol > 0) {
                    const gross = virtualWallet.sol * price;
                    const fee = gross * COMISION_BINANCE;
                    virtualWallet.usdt = gross - fee;
                    virtualWallet.sol = 0;
                    sellCount++;
                    console.log(`[Trade ${index}] 🔴 SELL SOL at $${price.toFixed(2)}`);
                }
            }
        });

        const finalPrice = parseFloat(trades[trades.length - 1].price);
        const finalValue = virtualWallet.usdt + (virtualWallet.sol * finalPrice);
        const netProfit = ((finalValue - 1000) / 1000) * 100;

        console.log('\n--- REPORTE FINAL: SOLANA ---');
        console.log(`Operaciones (B/S):  ${buyCount} Compras / ${sellCount} Ventas`);
        console.log(`Saldo Final:        $${finalValue.toFixed(4)} USDT`);
        console.log(`Rendimiento Neto:   ${netProfit >= 0 ? '+' : ''}${netProfit.toFixed(4)}%`);
        console.log('-----------------------------');

        if (buyCount > 0) {
            console.log('🚀 ¡Movimiento detectado! Solana nos dio la volatilidad que XRP no tenía.');
        } else {
            console.log('💡 El mercado está muy tranquilo ahorita, incluso para Solana.');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

runSolanaScalper();
