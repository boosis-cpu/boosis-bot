
const BINANCE_BTC_KLINES_URL = 'https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=100';

// --- CONFIGURACIÓN DE LA ESTRATEGIA: CÁMARA LENTA (1 Hora de Historia) ---
const WINDOW_SIZE = 10;        // Ventana de 10 minutos
const UMBRAL_SEÑAL = 0.0010;   // 0.10% (Buscamos movimientos reales de tendencia)
const COMISION_BINANCE = 0.0010; // 0.10%

async function runSlowMotionBacktest() {
    try {
        console.log('--- BINANCE BACKTEST: CÁMARA LENTA (BTC/USDT) ---');
        console.log('Descargando los últimos 100 minutos de historia...\n');

        const response = await fetch(BINANCE_BTC_KLINES_URL);
        const klines = await response.json();

        // Cada kline es: [time, open, high, low, close, volume, ...]
        // Nosotros usaremos el "precio de cierre" (Close price) en la posición 4.

        let virtualWallet = { usdt: 1000, btc: 0 };
        let history = [];
        let operations = [];

        console.log('Simulando la última hora y media de vida de Bitcoin...');

        klines.forEach((kline, index) => {
            const closePrice = parseFloat(kline[4]);
            const timestamp = new Date(kline[0]).toLocaleTimeString();

            history.push(closePrice);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (closePrice - sma) / sma;

                // COMPRA (El precio rompe el promedio hacia arriba)
                if (diff > UMBRAL_SEÑAL && virtualWallet.usdt > 0) {
                    const fee = virtualWallet.usdt * COMISION_BINANCE;
                    virtualWallet.btc = (virtualWallet.usdt - fee) / closePrice;
                    virtualWallet.usdt = 0;
                    operations.push({ type: 'BUY', time: timestamp, price: closePrice });
                }
                // VENTA (El precio cae por debajo del promedio)
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.btc > 0) {
                    const gross = virtualWallet.btc * closePrice;
                    const fee = gross * COMISION_BINANCE;
                    virtualWallet.usdt = gross - fee;
                    virtualWallet.btc = 0;
                    operations.push({ type: 'SELL', time: timestamp, price: closePrice });
                }
            }
        });

        // Reporte visual de la batalla
        operations.forEach(op => {
            console.log(`[${op.time}] ${op.type === 'BUY' ? '🟢' : '🔴'} ${op.type} at $${op.price.toFixed(2)}`);
        });

        const finalPrice = parseFloat(klines[klines.length - 1][4]);
        const finalValue = virtualWallet.usdt + (virtualWallet.btc * finalPrice);
        const netProfit = ((finalValue - 1000) / 1000) * 100;

        console.log('\n--- RESULTADO DE LA ÚLTIMA HORA ---');
        console.log(`Movimiento de Bitcoin: $${parseFloat(klines[0][4]).toFixed(2)} -> $${finalPrice.toFixed(2)}`);
        console.log(`Operaciones:           ${operations.length}`);
        console.log(`Saldo Final:           $${finalValue.toFixed(4)} USDT`);
        console.log(`Rendimiento Neto:      ${netProfit >= 0 ? '+' : ''}${netProfit.toFixed(4)}%`);
        console.log('---------------------------------');

        if (operations.length > 0) {
            console.log('🚀 ¡HABEMUS MOVIMIENTO! En 100 minutos Bitcoin siempre hace algo.');
        } else {
            console.log('💡 Increíble, Bitcoin está más quieto que una foto hoy.');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

runSlowMotionBacktest();
