
const XRP_MXN_TRADES_URL = 'https://api.bitso.com/v3/trades/?book=xrp_mxn';

// --- CONFIGURACIÓN DE LA ESTRATEGIA DE BACKTESTING ---
const WINDOW_SIZE = 20;       // Ventana para el promedio móvil
const UMBRAL_SEÑAL = 0.0010;  // 0.10% de desviación para comprar/vender (más exigente)
const COMISION = 0.0050;      // 0.50% de comisión por operación

async function runBacktest() {
    try {
        console.log('--- INICIANDO BACKTESTING EXPRESS (Renaissance Style) ---');
        console.log('Descargando los últimos 100 movimientos de XRP en Bitso...\n');

        const response = await fetch(XRP_MXN_TRADES_URL);
        const data = await response.json();

        if (!data.success) return;

        // Los trades vienen del más reciente al más antiguo. 
        // Para simular el tiempo, los invertimos para que vayan del pasado al presente.
        const trades = data.payload.reverse();

        let virtualWallet = { mxn: 1000, xrp: 0 };
        let history = [];
        let operationsCount = 0;

        console.log('Simulando operaciones sobre la historia...');

        trades.forEach((trade, index) => {
            const price = parseFloat(trade.price);
            history.push(price);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (price - sma) / sma;

                // Lógica de Compra
                if (diff > UMBRAL_SEÑAL && virtualWallet.mxn > 0) {
                    const costoComision = virtualWallet.mxn * COMISION;
                    const netoParaComprar = virtualWallet.mxn - costoComision;
                    virtualWallet.xrp = netoParaComprar / price;
                    virtualWallet.mxn = 0;
                    operationsCount++;
                    console.log(`[Trade ${index}] 🟢 COMPRA a $${price.toFixed(2)} | Comisión: $${costoComision.toFixed(2)}`);
                }
                // Lógica de Venta
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.xrp > 0) {
                    const ventaBruta = virtualWallet.xrp * price;
                    const costoComision = ventaBruta * COMISION;
                    virtualWallet.mxn = ventaBruta - costoComision;
                    virtualWallet.xrp = 0;
                    operationsCount++;
                    console.log(`[Trade ${index}] 🔴 VENTA  a $${price.toFixed(2)} | Comisión: $${costoComision.toFixed(2)}`);
                }
            }
        });

        const finalPrice = parseFloat(trades[trades.length - 1].price);
        const finalValue = virtualWallet.mxn + (virtualWallet.xrp * finalPrice);
        const profitTotal = ((finalValue - 1000) / 1000) * 100;

        console.log('\n--- RESULTADOS DEL EXPERIMENTO ---');
        console.log(`Movimientos analizados: 100`);
        console.log(`Operaciones realizadas: ${operationsCount}`);
        console.log(`Saldo Final:           $${finalValue.toFixed(2)} MXN`);
        console.log(`Rendimiento Neto:      ${profitTotal >= 0 ? '+' : ''}${profitTotal.toFixed(4)}%`);
        console.log('----------------------------------');

        if (profitTotal < 0) {
            console.log('💡 Lección: En periodos cortos o con mucha comisión, a veces "no operar" es la mejor estrategia.');
        } else {
            console.log('🚀 ¡El algoritmo encontró una veta de ganancia en el pasado!');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

runBacktest();
