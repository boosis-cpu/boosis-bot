
const BTC_MXN_TRADES_URL = 'https://api.bitso.com/v3/trades/?book=btc_mxn';
const fs = require('fs');

async function fetchHistoricalData() {
    try {
        console.log('--- COSECHANDO DATOS HISTÓRICOS ---');
        console.log('Conectando con la API de Bitso para obtener trades recientes...');

        const response = await fetch(BTC_MXN_TRADES_URL);
        const data = await response.json();

        if (data.success) {
            const trades = data.payload;
            const fileName = 'btc_mxn_history.json';

            // Guardamos los datos crudos en un archivo
            fs.writeFileSync(fileName, JSON.stringify(trades, null, 2));
            console.log(`\n✅ Éxito: Se han descargado ${trades.length} trades.`);
            console.log(`📁 Datos guardados en: ${fileName}`);

            // --- PEQUEÑO ANÁLISIS ESTADÍSTICO (Nivel Renaissange) ---
            const prices = trades.map(t => parseFloat(t.price));
            const maxPrice = Math.max(...prices);
            const minPrice = Math.min(...prices);
            const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;

            console.log('\n--- MICROSCOPIO DE DATOS ---');
            console.log(`Precio Máximo en este bloque: $${maxPrice.toLocaleString('es-MX')} MXN`);
            console.log(`Precio Mínimo en este bloque: $${minPrice.toLocaleString('es-MX')} MXN`);
            console.log(`Precio Promedio:              $${avgPrice.toLocaleString('es-MX')} MXN`);
            console.log(`Volatilidad (Rango):         $${(maxPrice - minPrice).toLocaleString('es-MX')} MXN`);

            // Detectar tendencia simple
            const firstPrice = prices[prices.length - 1]; // El más viejo del grupo
            const lastPrice = prices[0]; // El más reciente
            const trend = lastPrice > firstPrice ? '🟢 ALCISTA' : '🔴 BAJISTA';

            console.log(`Tendencia en este micro-periodo: ${trend}`);
            console.log('----------------------------\n');

        }
    } catch (error) {
        console.error('Error durante la cosecha:', error.message);
    }
}

fetchHistoricalData();
