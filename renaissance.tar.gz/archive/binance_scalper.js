
const BINANCE_XRP_TRADES_URL = 'https://api.binance.com/api/v3/trades?symbol=XRPUSDT&limit=500';

// --- CONFIGURACIÓN DEL MICRO-SCALPER (Sensibilidad Alta) ---
const WINDOW_SIZE = 10;        // Ventana muy corta para reaccionar rápido
const UMBRAL_SEÑAL = 0.0003;   // 0.03% (En Bitso esto sería suicidio, en Binance es posible)
const COMISION_BINANCE = 0.0010; // 0.10%

async function runBinanceScalper() {
    try {
        console.log('--- BINANCE MICRO-SCALPER SIMULATOR ---');
        console.log('Analizando 500 trades de XRP/USDT (Alta Sensibilidad)...\n');

        const response = await fetch(BINANCE_XRP_TRADES_URL);
        const trades = await response.json();

        let virtualWallet = { usdt: 1000, xrp: 0 };
        let history = [];
        let buyCount = 0;
        let sellCount = 0;

        trades.forEach((trade, index) => {
            const price = parseFloat(trade.price);
            history.push(price);
            if (history.length > WINDOW_SIZE) history.shift();

            if (history.length === WINDOW_SIZE) {
                const sma = history.reduce((a, b) => a + b, 0) / WINDOW_SIZE;
                const diff = (price - sma) / sma;

                // COMPRA
                if (diff > UMBRAL_SEÑAL && virtualWallet.usdt > 0) {
                    const fee = virtualWallet.usdt * COMISION_BINANCE;
                    virtualWallet.xrp = (virtualWallet.usdt - fee) / price;
                    virtualWallet.usdt = 0;
                    buyCount++;
                    console.log(`[Trade ${index}] 🟢 BUY  at $${price.toFixed(4)}`);
                }
                // VENTA
                else if (diff < -UMBRAL_SEÑAL && virtualWallet.xrp > 0) {
                    const gross = virtualWallet.xrp * price;
                    const fee = gross * COMISION_BINANCE;
                    virtualWallet.usdt = gross - fee;
                    virtualWallet.xrp = 0;
                    sellCount++;
                    console.log(`[Trade ${index}] 🔴 SELL at $${price.toFixed(4)}`);
                }
            }
        });

        const finalPrice = parseFloat(trades[trades.length - 1].price);
        const finalValue = virtualWallet.usdt + (virtualWallet.xrp * finalPrice);
        const netProfit = ((finalValue - 1000) / 1000) * 100;

        console.log('\n--- REPORTE FINAL DE SCALPING ---');
        console.log(`Trades procesados:   500`);
        console.log(`Operaciones (B/S):  ${buyCount} Compras / ${sellCount} Ventas`);
        console.log(`Saldo Final:        $${finalValue.toFixed(4)} USDT`);
        console.log(`Rendimiento Neto:   ${netProfit >= 0 ? '+' : ''}${netProfit.toFixed(4)}%`);
        console.log('---------------------------------');

        if (netProfit > 0) {
            console.log('🚀 ¡ESTRATEGIA RENTABLE! La baja comisión de Binance permitió ganar en micromovimientos.');
        } else {
            console.log('💡 Todavía falta ajustar el umbral, pero nota que la pérdida es mínima.');
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

runBinanceScalper();
